package com.org.ItemTracker;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.client.RestTemplate;

import com.org.ItemTracker.Repository.ItemRepository;
import com.org.ItemTracker.entity.Item;
import com.org.ItemTracker.service.ItemService;

public class ItemServiceTest {

	@InjectMocks
	private ItemService itemService;

	@Mock
	private ItemRepository itemRepository;

	@Mock
	private RestTemplate restTemplate;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testCreateItem() {

		Item item = new Item();
		item.setName("Test Item");

		when(itemRepository.save(any(Item.class))).thenReturn(item); // Use any() to allow flexibility

		Item createdItem = itemService.createItem(item);

		assertNotNull(createdItem);
		assertEquals("Test Item", createdItem.getName());

		verify(itemRepository, times(1)).save(any(Item.class));
	}

	@Test
	public void testGetItemById() {

		Long itemId = 1L;
		Item item = new Item();
		item.setId(itemId);
		item.setName("Test Item");
		when(itemRepository.findById(itemId)).thenReturn(Optional.of(item));

		Item foundItem = itemService.getItemById(itemId);

		assertNotNull(foundItem);
		assertEquals("Test Item", foundItem.getName());
		verify(itemRepository, times(1)).findById(itemId);
	}

	@Test
	public void testGetItemById_ItemNotFound() {

		Long itemId = 1L;
		when(itemRepository.findById(itemId)).thenReturn(Optional.empty());

		RuntimeException exception = assertThrows(RuntimeException.class, () -> itemService.getItemById(itemId));
		assertEquals("Item not found", exception.getMessage());
	}

	@Test
	public void testUpdateItem() {
		// Given
		Long itemId = 1L;
		Item existingItem = new Item();
		existingItem.setId(itemId);
		existingItem.setName("Old Item");

		Item updatedItem = new Item();
		updatedItem.setName("Updated Item");

		when(itemRepository.findById(itemId)).thenReturn(Optional.of(existingItem));
		when(itemRepository.save(existingItem)).thenReturn(existingItem);
		Item result = itemService.updateItem(itemId, updatedItem);
		assertNotNull(result);
		assertEquals("Updated Item", result.getName());
		verify(itemRepository, times(1)).save(existingItem);
	}

	@Test
	public void testDeleteItem() {

		Long itemId = 1L;

		itemService.deleteItem(itemId);

		verify(itemRepository, times(1)).deleteById(itemId);
	}

	@Test
	public void testSearchItems() {

		String name = "Test";
		Pageable pageable = PageRequest.of(0, 10);
		Page<Item> itemsPage = mock(Page.class);
		when(itemRepository.findByNameContaining(name, pageable)).thenReturn(itemsPage);

		Page<Item> result = itemService.searchItems(name, pageable);

		assertNotNull(result);
		verify(itemRepository, times(1)).findByNameContaining(name, pageable);
	}

	@Test
	public void testSearchItemsByCategory() {

		String category = "Electronics";
		Pageable pageable = PageRequest.of(0, 10);
		Page<Item> itemsPage = mock(Page.class);
		when(itemRepository.findItemsByCategoryName(category, pageable)).thenReturn(itemsPage);

		Page<Item> result = itemService.searchItemsByCategory(category, pageable);

		assertNotNull(result);
		verify(itemRepository, times(1)).findItemsByCategoryName(category, pageable);
	}

	@Test
	public void testFetchExternalData() {

		String expectedResponse = "Google Response";
		when(restTemplate.getForObject("https://www.google.com", String.class)).thenReturn(expectedResponse);

		String response = itemService.fetchExternalData();

		assertNotNull(response);
		assertEquals(expectedResponse, response);
		verify(restTemplate, times(1)).getForObject("https://www.google.com", String.class);
	}
}
