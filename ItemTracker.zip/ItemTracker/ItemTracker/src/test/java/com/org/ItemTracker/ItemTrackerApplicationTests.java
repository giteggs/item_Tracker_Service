package com.org.ItemTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
