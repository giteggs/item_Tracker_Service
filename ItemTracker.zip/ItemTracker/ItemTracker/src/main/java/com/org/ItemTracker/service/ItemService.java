package com.org.ItemTracker.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.org.ItemTracker.Repository.CategoryRepository;
import com.org.ItemTracker.Repository.ItemRepository;
import com.org.ItemTracker.entity.Category;
import com.org.ItemTracker.entity.Item;

@Service
public class ItemService {

	private final ItemRepository itemRepository;
	private final CategoryRepository categoryRepository; 
	private final RestTemplate restTemplate;

	@Autowired
	public ItemService(ItemRepository itemRepository, CategoryRepository categoryRepository,
			RestTemplate restTemplate) {
		this.itemRepository = itemRepository;
		this.categoryRepository = categoryRepository;
		this.restTemplate = restTemplate;
	}

	public Item createItem(Item item) {
	    Optional<Category> category = categoryRepository.findById(item.getCategory().getId());
	    if (!category.isPresent()) {
	        Category newCategory = new Category();
	        newCategory.setId(item.getCategory().getId());  
	        newCategory.setName(item.getCategory().getName());
	        categoryRepository.save(newCategory);  
	        item.setCategory(newCategory);  
	    }
	    return itemRepository.save(item);
	}


	public Item getItemById(Long id) {
		return itemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
	}

	public Item updateItem(Long id, Item updatedItem) {
		Item item = getItemById(id);
		item.setName(updatedItem.getName());

		Optional<Category> category = categoryRepository.findById(updatedItem.getCategory().getId());
		if (!category.isPresent()) {
			throw new RuntimeException("Category not found with ID: " + updatedItem.getCategory().getId());
		}

		item.setCategory(updatedItem.getCategory());
		return itemRepository.save(item);
	}

	public void deleteItem(Long id) {
		itemRepository.deleteById(id);
	}

	public Page<Item> searchItems(String name, Pageable pageable) {
		return itemRepository.findByNameContaining(name, pageable);
	}

	public Page<Item> searchItemsByCategory(String categoryName, Pageable pageable) {
		return itemRepository.findItemsByCategoryName(categoryName, pageable);
	}

	public String fetchExternalData() {
		return restTemplate.getForObject("https://www.google.com", String.class);
	}


}